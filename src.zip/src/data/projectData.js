export default [
  {
    platform: 'android',
    title: 'PROYECTO ANDROID',
    owner: 'Javier',
  },
  {
    platform: 'ios',
    title: 'PROYECTO IOS',
    owner: 'Marta',
  },
  {
    platform: 'web',
    title: 'PROYECTO WEB',
    owner: 'ROBERTO',
  },
  {
    platform: 'android',
    title: 'PROYECTO ANDROID',
    owner: 'Javier',
  },
  {
    platform: 'ios',
    title: 'PROYECTO IOS',
    owner: 'Marta',
  },
  {
    platform: 'web',
    title: 'PROYECTO WEB',
    owner: 'ROBERTO',
  },
  {
    platform: 'android',
    title: 'PROYECTO ANDROID',
    owner: 'Javier',
  },
  {
    platform: 'ios',
    title: 'PROYECTO IOS',
    owner: 'Marta',
  },
  {
    platform: 'web',
    title: 'PROYECTO WEB',
    owner: 'ROBERTO',
  },
]