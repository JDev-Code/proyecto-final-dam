import React from 'react'
import { View, Text } from 'react-native'
import LogInPage from '../pages/LogIn'
import SignUpPage from '../pages/SignUp'
import ProjectListPage from '../pages/ProjectList'
import Constants from 'expo-constants'
import { Route, Switch } from 'react-router-native'


function Main () {

  return (
    <View style={{ paddingTop: Constants.statusBarHeight, height: '100%' }}>
      <Switch>
        <Route path='/' exact>
          <LogInPage />
        </Route>
        <Route path='/signUp' exact>
          <SignUpPage />
        </Route>
        <Route path='/app'>
          <Switch>
            <View style={{ height: '100%'}}>
              <Route path='/app/projects' exact>
                <ProjectListPage />
              </Route>
              <Route path='/app/chat' exact>
                <></>
              </Route>
              <Route path='/app/myProfile' exact>
                <></>
              </Route>
              <Text style={{position: 'absolute', bottom: 0, backgroundColor: '#91b7f0ff', width: '100%', height: 50 }}>BARRA</Text>
            </View>
          </Switch>
        </Route>
      </Switch>
    </View>
  )
}

export default Main