import React from 'react'
import { Text } from 'react-native'

function StyledText () {

  return (
    <Text></Text>
  )
}

export default StyledText