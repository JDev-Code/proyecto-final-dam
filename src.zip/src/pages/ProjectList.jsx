import React from "react"
import { View, Text, FlatList } from 'react-native'
import projects from "../data/projectData"

function ProjectListPage () {
  console.log(projects)
  return (
    <FlatList
      data={projects}
      ItemSeparatorComponent={() => <Text style={{ backgroundColor: 'yellow' }}>ESPACIO</Text>}
      renderItem={({ item: project }) => {
        <ProjectItem {...project} />
      }}
    />
  )
}

function ProjectItem (project) {
  console.log('ITEM!')
  return (
    <View>
      <Text>hola</Text>
    </View>
  )

}

export default ProjectListPage