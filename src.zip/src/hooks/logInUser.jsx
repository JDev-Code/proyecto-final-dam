import React, { useState } from 'react'
import { useLocation } from 'react-router-native'

function logInUser () {
  const [state, setstate] = useState('hola');


  return ('')
}

export default logInUser